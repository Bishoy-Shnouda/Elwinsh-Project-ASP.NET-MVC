﻿namespace RescueSite.ViewModels
{
    public class CreateRequestVM
    {
        public int UserId { get; set; }
        public string carNum { get; set; }
        public string CarDetails { get; set; }
        public string Location { get; set; }
    }
}
