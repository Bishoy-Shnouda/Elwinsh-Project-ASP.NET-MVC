﻿namespace RescueSite.Const
{
    public class Auth
    {
        public static int UserId { get; set; }
        public static int RoleId { get; set; }
        public static string Name{ get; set; }

    }
}
